<div class="sidebar" data-color="orange" data-background-color="white" data-image="{{ asset('material') }}/img/sidebar-1.jpg">
  <div class="logo">
    <a href="" class="simple-text logo-normal">
      {{ __('SANA') }}
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">

      <li class="nav-item ">

        <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
        <i class="material-icons">settings_applications</i>

          <p>{{ __('Data Managment') }}
            <b class="caret"></b>
          </p>
        </a>
        <div class="collapse show" id="laravelExample">
          <ul class="nav">

            <li class="nav-item">
              <a class="nav-link" href="{{ route('profile.edit') }}">
              <i class="material-icons">person</i>
                <span class="sidebar-normal">{{ __('your profile') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('users') }}">
              <i class="material-icons">account_circle</i>
                <span class="sidebar-normal"> {{ __('User Management') }} </span>
              </a>
            </li>

            
            <li class="nav-item">
              <a class="nav-link" href="{{ route('admins') }}">
              <i class="material-icons">manage_accounts</i>
                <span class="sidebar-normal"> {{ __('Admin Management') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('services') }}">
              <i class="material-icons">design_services</i>
                <span class="sidebar-normal"> {{ __('Services Management') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('get_all_products') }}">
              <i class="material-icons">menu</i>
                <span class="sidebar-normal"> {{ __('Products Management') }} </span>
              </a>
            </li>

            
            <li class="nav-item">
              <a class="nav-link" href="{{ route('get_orders') }}">
              <i class="material-icons">menu</i>
                <span class="sidebar-normal"> {{ __('Orders Management') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('notifications') }}">
              <i class="material-icons">notifications</i>
                <span class="sidebar-normal"> {{ __('notification') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="{{ route('settings') }}">
              <i class="material-icons">settings</i>
                <span class="sidebar-normal"> {{ __('Settings') }} </span>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" style="background-color:#F44336;" href="{{ route('logout') }}">
              <i class="material-icons" style="color:#ffff">logout</i>
                <span class="sidebar-normal"  style="color:#ffff"> {{ __('Logout') }} </span>
              </a>
            </li>
          </ul>
        </div>
      </li>

    </ul>
  </div>
  </li>


  <li class="nav-item">
    <a class="nav-link" href="{{ route('table') }}">
      <i class="material-icons">content_paste</i>
      <p>{{ __('Table List') }}</p>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ route('typography') }}">
      <i class="material-icons">library_books</i>
      <p>{{ __('Typography') }}</p>
    </a>
  </li>

  <li class="nav-item">
    <a class="nav-link" href="{{ route('notifications') }}">
      <i class="material-icons">notifications</i>
      <p>{{ __('Notifications') }}</p>
    </a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="{{ route('language') }}">
      <i class="material-icons">language</i>
      <p>{{ __('RTL Support') }}</p>
    </a>
  </li>

  </ul>
</div>
</div>