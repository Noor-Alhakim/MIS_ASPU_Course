<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateMotionVideoRequest;
use App\Services\MotionService;
use Illuminate\Http\Request;

class MotionController extends Controller
{
    protected $MotionService ;

    public function __construct(MotionService $service) {
        $this->MotionService = $service;
    }

    public function get_videos(){
        $res = $this->MotionService->index();
        return $res ;
    }

    public function add_video(CreateMotionVideoRequest $request){
        $res = $this->MotionService->create($request);
        return $res ;
    }

    
    public function delete_video($id){
        $res = $this->MotionService->delete($id);
        return $res ;
    }
    
}
