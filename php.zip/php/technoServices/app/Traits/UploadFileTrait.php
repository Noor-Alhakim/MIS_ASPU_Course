<?php

namespace App\Traits;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

trait UploadFileTrait
{
    public function upload_file($image,$folder){
        $extension = $image->getClientOriginalExtension();
        $filename = time().'.'.$extension;

        $path = Storage::disk('public')->put("$folder", $image);
        return "images/$path";
    }

    public function delete_last_image($image){
        File::delete($image);
        return true ;
    
    }
}
