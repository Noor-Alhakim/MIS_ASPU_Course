<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\AppService;
use Illuminate\Http\Request;

class AppController extends Controller
{
    protected $appService ;

    public function __construct(AppService $service) {
        $this->appService = $service;
    }

    public function get_apps(){
        $res = $this->appService->index();
        return $res ;
    }



}
