<?php

namespace App\Services;

use App\Models\Social_media_design;
use App\Models\SocialMediaDesign;
use App\Traits\UploadFileTrait;

class SocialMediaService
{
    use UploadFileTrait;

    public function index()
    {
        $designs = Social_media_design::orderby('sid',"Asc")->get();
        return response()->json([
            'designs' => $designs,
        ], 200);
    }

    public function sort_images($request)
    {
        $arr =  json_decode($request->sort);
        foreach ($arr as $item) {
            $design = Social_media_design::findOrFail($item->id);
            $design->sid = $item->sort;
            $design->save();
        }

        $designs = $this->index();
        return $designs;
    }

    public function create($request)
    {
        if ($request->file('image') != null) {
            $path = $this->upload_file($request->file('image'), "SocialMedia");
        }

        $count = Social_media_design::count();
     
        $new_design = new Social_media_design();
        $new_design->sid = $count + 1 ;
        $new_design->image_url = "/$path";
        $new_design->save();

        return response()->json([
            'msg' => 'created_successfully',
        ], 200);
    }

    public function delete($id)
    {
        $design = Social_media_design::findOrFail($id);
        $design->delete();

        return response()->json([
            'msg' => 'deleted_successfully',
        ], 200);
    }
}
