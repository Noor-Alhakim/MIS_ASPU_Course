<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\MotionService;
use Illuminate\Http\Request;

class MotionController extends Controller
{  
    protected $MotionService ;

    public function __construct(MotionService $service) {
        $this->MotionService = $service;
    }

    public function get_videos(){
        $res = $this->MotionService->index();
        return $res ;
    }
}
