import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { Language } from "../../Components/Container/Container";
import { useTranslation } from "react-i18next";
// import "../SubCategories/SubCategories.scss";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCloudArrowUp,
  faPenToSquare,
  faTrash,
  faVideo,
} from "@fortawesome/free-solid-svg-icons";
import LinearProgress from "@mui/material/LinearProgress";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { useNavigate } from "react-router-dom";
import { useCookies } from "react-cookie";
export default function Category() {
  const [cookies, setCookies] = useCookies(["access_token"]);
  const navigate = useNavigate();
  // show image or span
  const [imgSpan, setImgSpan] = useState(false);
  const [videoSpan, setVideoSpan] = useState(false);
  // to show loading when fetch
  const [loading, setLoading] = useState(true);
  // to show Table or Form when click on add or edit button
  const [showTableForm, setShowTableForm] = useState(true);
  // show add button or cancel
  const [addCancel, setAddCancel] = useState(true);
  // to show add button on submit or edit button
  const [bool, setBool] = useState(true);

  // id when edit to send it to submit function
  const [idEdit, setIdEdit] = useState(0);
  // from container contains which language we use
  const language = useContext(Language);
  // to translate
  const [t] = useTranslation();
  // ***** to fetch *****//
  const [arabicName, setArabicName] = useState("");
  const [englishName, setEnglishName] = useState("");
  const [orderName, setOrderName] = useState("");
  // save api info in it
  const [todos, setTodos] = useState([]);

  // fetch data
  function LinearProgressWithLabel(props) {
    return (
      <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
        <Box sx={{ width: "100%", mr: 1 }}>
          <LinearProgress variant="determinate" {...props} className="w-100" />
        </Box>
        <Box sx={{ minWidth: 35 }}>
          <Typography
            sx={{ color: "#fff" }}
            variant="body2"
            color="text.secondary"
          >{`${Math.round(props.value)}%`}</Typography>
        </Box>
      </Box>
    );
  }
  const fetchTodos = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_URL}admin/videos`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
        }
      );
      setTodos(response.data.videos);
      // hide loading after fetch
      setLoading(false);
    } catch (error) {
      console.error("Error fetching todos:", error);
      // hide loading after fetch
      setLoading(false);
      if (error.response.status) {
        setCookies("access_token", "");
        localStorage.removeItem("access_token");
        navigate("/");
      }
    }
  };
  useEffect(() => {
    fetchTodos();
  }, []);

  const ShowAddForm = () => {
    // to show add button on submit
    setBool(true);
    // to show span image circle
    setImgSpan(false);
    setVideoSpan(false);
    // show Form hide table
    setShowTableForm(false);
    // show cancel button
    setAddCancel(false);
    // get inputs and make them empty
    // const orderNumber = document.querySelector(".orderNumber");
    // const arabic = document.querySelector(".arabic");
    // const english = document.querySelector(".english");
    // orderNumber.value = "";
    // arabic.value = "";
    // english.value = ""; // bool = !bool;
    // console.log(bool);
    // remove Text
    setTimeout(() => {
      const inputsUse = document.querySelectorAll(".inputUse");
      inputsUse.forEach((input) => {
        input.value = "";
      });
    }, 0);
  };
  // console.log(ShowFormEdit);
  const addEdit = async (e) => {
    try {
      // stop submit refresh
      e.preventDefault();
      // show add button
      setAddCancel(true);
      // show table hide form
      setShowTableForm(true);
      // remove the text from all inputs after added
      setTimeout(() => {
        const inputsUse = document.querySelectorAll(".inputUse");
        inputsUse.forEach((input) => {
          input.value = "";
        });
      }, 0);
      const rest = await axios.put(`http://localhost:5000/todo/${idEdit}`, {
        completed: false,
        // warning change this to the id that will come from api //////////////////////
        image: image,
        arabic: arabicName.trim(""),
        english: englishName.trim(""),
        order: orderName,
      });
      // refresh api to show the new
      fetchTodos();
    } catch (error) {
      console.log("something went wrong", error);
    }
  };

  // const blur = (e) => {
  //   // to return search input to the normal status
  //   const blur = document.querySelector(".blur");
  //   blur.classList.remove("focus", "focusLg");
  //   e.target.classList.remove("focus");
  // };
  // const focus = (e) => {
  //   // styling search input on focus
  //   const blur = document.querySelector(".blur");
  //   blur.classList.add("focus", "focusLg");
  //   e.target.classList.add("focus");
  // };

  const addTodo = async (e) => {
    try {
      e.preventDefault();
      const formData = new FormData();
      formData.append("video_image", image);
      formData.append("video", video);
      setProgress(true);
      const res = await axios.post(
        `${process.env.REACT_APP_API_URL}admin/videos/create`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
          onUploadProgress: function (event) {
            // console.log(event);
            // if (event.lengthComputable) {
            // حساب نسبة التقدم
            let progressValue = Math.round((event.loaded / event.total) * 100);
            setProgressV(progressValue);
          },
        }
      );
      // add a new info to api
      // refresh api in the page
      // show table hide form
      // show cancel button
      setAddCancel(true);
      //
      setShowTableForm(true);
      // remove the text from all inputs after added
      setTimeout(() => {
        const inputsUse = document.querySelectorAll(".inputUse");
        inputsUse.forEach((input) => {
          input.value = "";
        });
      }, 0);
      setProgress(false);

      fetchTodos();
    } catch (error) {
      setProgress(false);

      console.error("Error adding todo:", error);
      if (error.response.status) {
        setCookies("access_token", "");
        localStorage.removeItem("access_token");
        navigate("/");
      }
    }
  };

  const deleteTodo = async (id) => {
    try {
      await axios.get(
        `${process.env.REACT_APP_API_URL}admin/videos/delete/${id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("access_token")}`,
          },
        }
      );
      // refresh api in the page
      fetchTodos();
    } catch (error) {
      console.error("Error deleting todo:", error);
      if (error.response.status) {
        setCookies("access_token", "");
        localStorage.removeItem("access_token");
        navigate("/");
      }
    }
  };
  const [image, setImage] = useState("");
  const [video, setVideo] = useState("");
  const handleImageChange = async (files) => {
    // the file in input that we uploaded it
    const selectedImage = files[0];
    const reader = new FileReader();
    const imgForm = document.querySelector(".imgForm");
    if (selectedImage) {
      reader.onload = function (e) {
        imgForm.src = reader.result; // تحديث src لـ imgForm بقيمة الصورة المحملة
      };
      reader.readAsDataURL(selectedImage);
    }
    // كائن لتخزين الصورة
    // const formData = new FormData();
    // formData.append("image", selectedImage);
    setImgSpan(true);
    // after api we need to edit
    // formData.append("image", selectedImage);
    setImage(selectedImage);
  };
  const handleVideoChange = async (files) => {
    // the file in input that we uploaded it
    const selectedVideo = files[0];
    const reader = new FileReader();
    const videoSrc = document.querySelector(".videoSpan");
    if (selectedVideo) {
      reader.onload = function (e) {
        videoSrc.src = reader.result; // تحديث src لـ imgForm بقيمة الصورة المحملة
      };
      reader.readAsDataURL(selectedVideo);
    }

    // كائن لتخزين الصورة
    // const formData = new FormData();
    // formData.append("image", selectedImage);
    setVideoSpan(true);
    // after api we need to edit
    // formData.append("image", selectedImage);
    setVideo(selectedVideo);
  };
  // add file to make another button that we can to style it
  const clickInputFile = () => {
    const inputFile = document.querySelector('input[type="file"]');
    inputFile.click();
  };
  //
  const Cancel = () => {
    // show table hide form
    setShowTableForm(true);
    // show add button
    setAddCancel(true);
    // remove Text
    setTimeout(() => {
      const inputsUse = document.querySelectorAll(".inputUse");
      inputsUse.forEach((input) => {
        input.value = "";
      });
    }, 0);
  };
  const [disabledBool, setDisabledBool] = useState(false);
  // english

  // const validateEnglishInput = (inputValue) => {
  //   return englishPattern.test(inputValue);
  // };
  const onDragOver = (event) => {
    event.preventDefault();
    // const spanDrag = document.querySelector(".spanDrag");
    const spanDrag = document.querySelector(".spanDrag");
    spanDrag.style.cssText = "background:#7a7a7a3b !important;";
  };
  const onDragLeave = (event) => {
    const spanDrag = document.querySelector(".spanDrag");
    event.preventDefault();
    spanDrag.style.cssText = "";
  };
  const onDrop = (event) => {
    event.preventDefault();
    const files = event.dataTransfer.files;
    handleImageChange(files);
  };
  const [disabledBoolEn, setDisabledBoolEn] = useState(false);
  const [progress, setProgress] = useState(false);
  const [progressV, setProgressV] = useState(0);
  return (
    <>
      <div className="head radius-5 position-relative fontChangeSmall bg-boxes p-2 p-md-3 d-flex align-items-center justify-content-between">
        <h6 className="mb-0 fontChangeSmall">{t("Best selling")}</h6>
        <div className="info d-flex align-items-center justify-content-between gap-2">
          {/*  */}
          {addCancel ? (
            <button
              className="px-2 px-md-3 py-1 radius-8"
              onClick={ShowAddForm}
            >
              {t("add")}
            </button>
          ) : (
            <button
              className="px-2 px-md-3 py-1 radius-8 bg-danger text-white"
              onClick={Cancel}
            >
              {t("cancel")}
            </button>
          )}
        </div>
      </div>
      {/* if true show table false show form */}
      {showTableForm ? (
        <div className="table-responsive DivSubTable fontChangeSmall">
          <table className="table subTable table table-striped table-hover">
            {/* <caption>List of users</caption> */}
            <thead>
              <tr className="text-center">
                <th scope="col">{t("Image")}</th>
                {/* <th scope="col">{t("arabic")}</th>
                <th scope="col">{t("english")}</th>
                <th scope="col">{t("orderNumber")}</th> */}
                <th scope="col">{t("Delete")}</th>
              </tr>
            </thead>
            {loading ? (
              <div className="text-center noData">
                <div className="spinner-border" role="status">
                  <span className="visually-hidden">Loading...</span>
                </div>
              </div>
            ) : todos.length > 0 ? (
              <tbody className="tbody">
                {todos?.map((item) => {
                  return (
                    <tr key={item.id}>
                      <td scope="row">
                        {/* {item.image_url && ( */}
                        <a
                          href={`${process.env.REACT_APP_API_URL_IMAGE}${item.video_url}`}
                          target="_blank"
                        >
                          <img
                            className="tableImg"
                            src={`${process.env.REACT_APP_API_URL_IMAGE}${item.video_image}`}
                            alt="Item"
                          />
                        </a>
                        {/* )} */}
                      </td>

                      <td>
                        <div
                          className="d-flex"
                          style={{ width: "fit-content", margin: "0 auto" }}
                        >
                          <FontAwesomeIcon
                            icon={faTrash}
                            onClick={() => deleteTodo(item.id)}
                            className="mainColorText pointer"
                            size="lg"
                          />
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            ) : (
              <div className="noData fw-bold text-capitalize text-center position-absolute">
                {t("noData")}
              </div>
            )}
          </table>
        </div>
      ) : (
        <>
          <form
            className=" pb-5 py-3 form fontChangeSmall d-flex flex-column justify-content-center align-items-center "
            onSubmit={bool ? addTodo : addEdit}
          >
            <div className="d-flex justify-content-center flex-column flex-lg-row align-items-center gap-4 w-100">
              <label htmlFor="drag" className="position-relative labelImage">
                <img
                  alt={"no "}
                  src={``}
                  className={`mb-2 imgForm ${imgSpan ? "d-block" : "d-none"}`}
                  // onClick={clickInputFile}
                />
                <span
                  className={`spanForm ${
                    imgSpan ? "d-none" : "d-grid"
                  } fs-5 spanDrag`}
                  // onClick={clickInputFile}
                >
                  <FontAwesomeIcon
                    icon={faCloudArrowUp}
                    style={{ color: "var(--clr-product)" }}
                    size="4x"
                  />
                </span>
                <input
                  className={`${language == "ar" ? "ar" : ""} inputUse`}
                  type="file"
                  accept="image/*"
                  onChange={(event) => handleImageChange(event.target.files)}
                  // onDrag={(event)}
                  onDragOver={onDragOver}
                  onDrop={onDrop}
                  onDragLeave={onDragLeave}
                  id="drag"
                  // required
                />
              </label>
              <label
                htmlFor="dragVideo"
                className="position-relative labelImage"
              >
                <video
                  src={``}
                  controls
                  autoPlay
                  className={`mb-2 videoSpan ${
                    videoSpan ? "d-block" : "d-none"
                  }`}
                ></video>
                <span
                  className={`spanForm ${
                    videoSpan ? "d-none" : "d-grid"
                  } fs-5 spanDrag`}
                  // onClick={clickInputFile}
                >
                  <FontAwesomeIcon
                    icon={faVideo}
                    style={{ color: "var(--clr-product)" }}
                    size="4x"
                  />
                </span>
                <input
                  className={`${language == "ar" ? "ar" : ""} inputUse`}
                  type="file"
                  // accept="image/*"
                  onChange={(event) => handleVideoChange(event.target.files)}
                  // onDrag={(event)}
                  // onDragOver={onDragOver}
                  // onDrop={onDrop}
                  // onDragLeave={onDragLeave}
                  id="dragVideo"
                  // required
                />
              </label>
            </div>
            {bool ? (
              <>
                {progress ? (
                  <div className="d-flex justify-content-center align-items-center gap-2 w-100">
                    <LinearProgressWithLabel
                      value={progressV}
                      color="primary"
                      // className="w-100"
                    />
                    {/* <span className="text-white">{progress}%</span> */}
                  </div>
                ) : (
                  <input
                    className="changeWidth btnForDelete text-white p-3"
                    type="submit"
                    value={`${t("add")}`}
                    disabled={
                      disabledBool === true || disabledBoolEn === true
                        ? true
                        : false
                    }
                  />
                )}
              </>
            ) : (
              <input
                className="changeWidth btnForEdit w-50 border-0 text-white py-2"
                type="submit"
                value={t("Edit")}
                style={{ background: "blue" }}
                disabled={
                  disabledBool === true || disabledBoolEn === true
                    ? true
                    : false
                }
              />
            )}
          </form>
        </>
      )}
    </>
  );
}
