<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateAppRequest;
use App\Http\Requests\UpdateAppRequest;
use App\Services\AppService;
use Illuminate\Http\Request;

class AppController extends Controller
{
    protected $appService ;

    public function __construct(AppService $service) {
        $this->appService = $service;
    }

    public function get_apps(){
        $res = $this->appService->index();
        return $res ;
    }

    public function add_app(CreateAppRequest $request){
        $res = $this->appService->create($request);
        return $res ;
    }

    public function update_app(UpdateAppRequest $request){
        $res = $this->appService->update($request);
        return $res ;
    }

    public function delete_app($id){
        $res = $this->appService->delete($id);
        return $res ;
    }
}
