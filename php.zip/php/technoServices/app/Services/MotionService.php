<?php

namespace App\Services;

use App\Models\Motion_video;
use App\Models\SocialMediaDesign;
use App\Traits\UploadFileTrait;

class MotionService
{
    use UploadFileTrait;

    public function index()
    {
        $videos = Motion_video::all();
        return response()->json([
            'videos' => $videos,
        ], 200);
    }

    public function create($request)
    {
        if ($request->file('video_image') != null) {
            $path_ = $this->upload_file($request->file('video_image'), "Motions");
        }

        if ($request->file('video') != null) {
            $path = $this->upload_file($request->file('video'), "Motions");
        }

        $new_video = new Motion_video();
        $new_video->video_image = "/$path_";
        $new_video->video_url = "/$path";
        $new_video->save();

        return response()->json([
            'msg' => 'created_successfully',
        ], 200);
    }

    public function delete($id)
    {
        $video = Motion_video::findOrFail($id);
        $video->delete();

        return response()->json([
            'msg' => 'deleted_successfully',
        ], 200);
    }
}
