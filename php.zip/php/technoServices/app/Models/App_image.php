<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class App_image extends Model
{
    use HasFactory;

    protected $table = "apps_images";
    
    protected $fillable = [
        'app_id',
        'image_url',
    ];
}
