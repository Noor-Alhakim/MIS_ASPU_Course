<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateSocialMediaDesignRequest;
use App\Services\SliderService;
use App\Services\SocialMediaService;
use Illuminate\Http\Request;

class SocialMediaController extends Controller
{
    protected $SocialMediaService ;

    public function __construct(SocialMediaService $service) {
        $this->SocialMediaService = $service;
    }

    public function get_designs(){
        $res = $this->SocialMediaService->index();
        return $res ;
    }

    public function sort_images(Request $request){
        $res = $this->SocialMediaService->sort_images($request);
        return $res ;
    }

    public function add_design(CreateSocialMediaDesignRequest $request){
        $res = $this->SocialMediaService->create($request);
        return $res ;
    }
    
    public function delete_design($id){
        $res = $this->SocialMediaService->delete($id);
        return $res ;
    }
}
