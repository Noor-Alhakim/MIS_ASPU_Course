<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdminLoginRequest;
use App\Services\AdminService;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    protected $adminService ;

    public function __construct(AdminService $service) {
        $this->adminService = $service;
    }

    public function login(AdminLoginRequest $request){

        $res = $this->adminService->login($request);
        return $res ;
    }

    public function logout(Request $request)
    {
        $data = $this->adminService->logout($request);
        return $data;
    }

}
