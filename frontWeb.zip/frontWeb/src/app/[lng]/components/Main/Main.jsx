"use client";
import React from "react";
import animationData from "./Logo.json";
import { useTranslation } from "@/app/i18n/client";
const Main = ({ lng }) => {
  // console.log(Lottie);
  const { t } = useTranslation(lng);

  // الكود الذي يستخدم كائن document يمكن وضعه هنا
  return (
    <div className="mx-auto flex flex-col items-center justify-center relative left-[50%] top-[60px] -translate-x-1/2 w-full">
      <div className="capitalize text-xl md:text-2xl lg:text-3xl font-semibold relative text-center top-[-20px]">
        {t("enhance")}
        <br />
        <span className="text-[#00BBFF] mt-2 block">{t("digital")}</span>
      </div>
    </div>
  );
};

export default Main;
