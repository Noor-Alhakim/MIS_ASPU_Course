-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2024 at 01:19 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `technoservices`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `user_name`, `password`, `created_at`, `updated_at`) VALUES
(1, 'yousef', 'yousef_1', '$2y$12$Z0nt1nr3VSVA9bcPQyQfX.z/A.1c03Ml32IInE3WY6nIKzYb1E4Yi', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `apps`
--

CREATE TABLE `apps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `main_image` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `apps`
--

INSERT INTO `apps` (`id`, `name`, `description`, `main_image`, `created_at`, `updated_at`) VALUES
(49, 'Taha', 'LOREM IMPSUM HI HELLO WE ARE TECHNO PLUS COMPANY THIS IS TAHA APP I DONT KNOW LOREM IPSUM', '/images/App_images/Y2vtcJBJaxRKCChyMRuQR2WUGIQkCjF5Kb91cT2Y.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(52, 'Dopamin', 'LOREM IMPSUM HI HELLO WE ARE TECHNO PLUS COMPANY THIS IS TAHA APP I DONT KNOW LOREM IPSUM', '/images/App_images/d0cXYXxcuxNg4cu0MZvHdhyWu3Lhp5OLQkSVngpU.jpg', '2024-03-18 08:43:52', '2024-03-30 04:19:09');

-- --------------------------------------------------------

--
-- Table structure for table `apps_images`
--

CREATE TABLE `apps_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `app_id` bigint(20) UNSIGNED NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `apps_images`
--

INSERT INTO `apps_images` (`id`, `app_id`, `image_url`, `created_at`, `updated_at`) VALUES
(153, 49, '/images/App_images/vW7zgkDb2QaIl3vRuxkL1y2TSPJlz5CpTVtCLkwD.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(154, 49, '/images/App_images/T2RLcOSUa5aKHeWxjQM0aZmqCVyoMViLEMu1KqsX.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(155, 49, '/images/App_images/SgyRmkskUgdiMAlb6GHPQh2o9cS9IufbXWLna1bf.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(156, 49, '/images/App_images/Rxm3yN4wNgR8aJRDwFh9hnF9VkUvQHi36XHbLQPg.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(157, 49, '/images/App_images/8ViNwCHeZddkz9io0M1WUhZG2Ol987DGp5hDYuOX.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(158, 49, '/images/App_images/UCS9tbj8YTO7cU2iHwVmelnxwtZxhjVVWtGYiR9F.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(159, 49, '/images/App_images/uVXMG4sb78qkYSUb2Oxe3pfZrPxvQQFNhvcu085A.png', '2024-03-18 08:43:52', '2024-03-18 08:43:52'),
(171, 52, '/images/App_images/faCW4YYKJkWTFw5UPJAyRISDp93ZuaUU5pYRUn1y.png', '2024-03-30 04:19:09', '2024-03-30 04:19:09'),
(172, 52, '/images/App_images/DmNEdGtsNhiyZ2RzLqLf7E6xfKBnUE5FqnJKlkla.jpg', '2024-03-30 04:19:09', '2024-03-30 04:19:09'),
(173, 52, '/images/App_images/tATd9AwVRkeNFH7DIyXkjpRt7ntE2A90tDpIhVbz.jpg', '2024-03-30 04:19:09', '2024-03-30 04:19:09');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2024_03_17_071711_create_social_media_designs_table', 1),
(6, '2024_03_17_081700_create_motions_videos_table', 2),
(7, '2024_03_17_084353_create_apps_table', 3),
(8, '2024_03_17_085140_create_apps_images_table', 4),
(9, '2024_03_18_055738_create_admins_table', 5);

-- --------------------------------------------------------

--
-- Table structure for table `motions_videos`
--

CREATE TABLE `motions_videos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `video_image` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `motions_videos`
--

INSERT INTO `motions_videos` (`id`, `video_image`, `video_url`, `created_at`, `updated_at`) VALUES
(5, '/images/Motions/1710667357.png', '/images/Motions/1710667357.png', '2024-03-17 06:22:37', '2024-03-17 06:22:37'),
(6, '/images/Motions/BxW7urKUh0Jj9yMnSf9fnGtVNeqKAFLCIEC36N4x.jpg', '/images/Motions/DLf1FfVsO98dScjGSHtkVTEfwyX0yqMQ5XzNvLKB.mp4', '2024-03-19 08:25:51', '2024-03-19 08:25:51');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(19, 'App\\Models\\Admin', 1, 'AUTH', '3db3c044a61f5e66c019dfdbd2f06b500f99f79f30e11e4b65fc935e410236d7', '[\"*\"]', '2024-03-24 10:03:01', NULL, '2024-03-24 09:48:47', '2024-03-24 10:03:01'),
(20, 'App\\Models\\Admin', 1, 'AUTH', '163dbef2b957e915078476d99fdc646c301ef2111fb5126254247035a58ade93', '[\"*\"]', '2024-03-30 04:19:09', NULL, '2024-03-30 03:48:09', '2024-03-30 04:19:09'),
(21, 'App\\Models\\Admin', 1, 'AUTH', '1d7e7315489ca0c0c22dd9ec6ced8c92f3651eeb1b70cf73fc59546b6019ab85', '[\"*\"]', '2024-04-01 06:28:12', NULL, '2024-04-01 05:58:55', '2024-04-01 06:28:12'),
(22, 'App\\Models\\Admin', 1, 'AUTH', '94339f73fb09bfef994801f1a05b0a9bb421c3edffda606886e6613a0d8587cf', '[\"*\"]', '2024-04-01 06:56:23', NULL, '2024-04-01 06:12:47', '2024-04-01 06:56:23');

-- --------------------------------------------------------

--
-- Table structure for table `social_media_designs`
--

CREATE TABLE `social_media_designs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sid` int(11) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_media_designs`
--

INSERT INTO `social_media_designs` (`id`, `sid`, `image_url`, `created_at`, `updated_at`) VALUES
(7, 1, '/images/SocialMedia/1710666277.png', '2024-03-17 06:04:37', '2024-04-01 06:54:32'),
(8, 4, '/images/SocialMedia/1710666289.png', '2024-03-17 06:04:49', '2024-04-01 06:56:20'),
(9, 2, '/images/SocialMedia/1710666297.png', '2024-03-17 06:04:57', '2024-04-01 06:56:17'),
(13, 3, '/images/SocialMedia/1710667157.png', '2024-03-17 06:19:17', '2024-04-01 06:56:17'),
(16, 5, '/images/SocialMedia/gAIWrzIBzk2D9XeBBazLuvvlQVikQlmp784WhevF.jpg', '2024-04-01 06:23:27', '2024-04-01 06:56:20');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_user_name_unique` (`user_name`);

--
-- Indexes for table `apps`
--
ALTER TABLE `apps`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apps_images`
--
ALTER TABLE `apps_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `apps_images_app_id_foreign` (`app_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `motions_videos`
--
ALTER TABLE `motions_videos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `social_media_designs`
--
ALTER TABLE `social_media_designs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `apps`
--
ALTER TABLE `apps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `apps_images`
--
ALTER TABLE `apps_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=174;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `motions_videos`
--
ALTER TABLE `motions_videos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `social_media_designs`
--
ALTER TABLE `social_media_designs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `apps_images`
--
ALTER TABLE `apps_images`
  ADD CONSTRAINT `apps_images_app_id_foreign` FOREIGN KEY (`app_id`) REFERENCES `apps` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
