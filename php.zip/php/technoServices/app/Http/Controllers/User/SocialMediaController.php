<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\SocialMediaService;
use Illuminate\Http\Request;

class SocialMediaController extends Controller
{
    protected $SocialMediaService ;

    public function __construct(SocialMediaService $service) {
        $this->SocialMediaService = $service;
    }

    public function get_designs(){
        $res = $this->SocialMediaService->index();
        return $res ;
    }

    
}
