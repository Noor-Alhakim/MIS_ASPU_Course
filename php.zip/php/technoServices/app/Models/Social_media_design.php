<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Social_media_design extends Model
{
    use HasFactory;

    protected $table = "social_media_designs";
    
    protected $fillable = [
        'image_url',
    ];
}
