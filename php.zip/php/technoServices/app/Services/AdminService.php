<?php

namespace App\Services;

use App\Models\Admin;
use App\Models\App;
use App\Models\App_image;
use App\Traits\UploadFileTrait;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AdminService
{
    use UploadFileTrait;

    public function login($request)
    {
        $login_info = $request->all();

        $admin = Admin::where('user_name', $login_info['user_name'])->first();

        if (!$admin || !Hash::check($login_info['password'], $admin->password)) {
            return response()->json([
                'error' => 'wrong_credential'
            ], 400);
        }

        $admin->save();

        $token = $admin->createToken('AUTH')->plainTextToken;

        return response()->json([
            'msg' => 'successful_login',
            'token' => $token,
            'admin' => collect($admin)->except('password', 'created_at', 'updated_at'),
        ], 200);
    }


    public function logout($request)
    {
        $request->user()->tokens()->delete();
        return response()->json([
            'msg' =>  'successful_logout',
        ], 200);
    }

}
