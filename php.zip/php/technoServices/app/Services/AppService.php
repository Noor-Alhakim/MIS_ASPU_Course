<?php

namespace App\Services;

use App\Models\App;
use App\Models\App_image;
use App\Traits\UploadFileTrait;
use Illuminate\Support\Facades\Log;

class AppService
{
    use UploadFileTrait;

    public function index()
    {
        $apps = App::all();

        foreach ($apps as $item) {
            $images = $item->images()->select('image_url')->get();
            $images[0] = ["image_url" => $item->main_image];

            $item['images'] = $images;
        }

        return response()->json([
            'apps' => $apps,
        ], 200);
    }

    public function create($request)
    {

        if ($request->file('main_image') != null) {
            $path = $this->upload_file($request->file('main_image'), "App_images");
        }

        $app = new App();
        $app->name = $request->name;
        $app->description = $request->description;
        $app->main_image = "/$path";
        $app->save();

        foreach ($request->file('images') as $item) {
            $path_ = $this->upload_file($item, "App_images");

            $image = new App_image();
            $image->app_id = $app->id;
            $image->image_url = "/$path_";
            $image->save();
        }

        return $app;
    }

    public function update($request)
    {
        $app = App::findorfail($request->id);
        $app->name = $request->name;
        $app->description = $request->description;

        if ($request->file('main_image') != null) {
            $path = $this->upload_file($request->file('main_image'), "App_images");
            $this->delete_last_image($app->main_image);

            $app->main_image = "/$path";
        }

        $app->save();

        if ($request->file('images')) {
            foreach ($app->images as $item) {
                $item->delete();
                $this->delete_last_image($item);
            }

            foreach ($request->file('images') as $item) {
                $path_ = $this->upload_file($item, "App_images");

                $image = new App_image();
                $image->app_id = $app->id;
                $image->image_url = "/$path_";
                $image->save();
            }
        }

        return $app;
    }

    public function delete($id)
    {
        $app = App::findorfail($id);
        $app->delete();

        return response()->json([
            'msg' => 'deleted_successfully',
        ], 200);
    }
}
