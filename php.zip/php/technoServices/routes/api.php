<?php

use App\Http\Controllers\Admin\AppController as AdminAppController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\MotionController as AdminMotionController;
use App\Http\Controllers\Admin\SocialMediaController as AdminSocialMediaController;
use App\Http\Controllers\User\AppController;
use App\Http\Controllers\User\MotionController;
use App\Http\Controllers\User\SocialMediaController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::group(['prefix' => "/user"], function () {

    Route::group(['prefix' => "/socialMedia"], function () {
        Route::get('/', [SocialMediaController::class, 'get_designs']);
    });

    Route::group(['prefix' => "/videos"], function () {
        Route::get('/', [MotionController::class, 'get_videos']);
    });

    Route::group(['prefix' => "/apps"], function () {
        Route::get('/', [AppController::class, 'get_apps']);
    });
});


Route::post('/admin/login', [AuthController::class,'login']);

Route::group(['prefix' => "/admin" ,'middleware' => ['auth:admins']], function () {

    Route::get('/logout', [AuthController::class,'logout']);
    
    Route::group(['prefix' => "/socialMedia"], function () {
        Route::get('/', [AdminSocialMediaController::class, 'get_designs']);
        Route::post('/sort_images', [AdminSocialMediaController::class, 'sort_images']);
        Route::post('/create', [AdminSocialMediaController::class, 'add_design']);
        Route::get('/delete/{id}', [AdminSocialMediaController::class, 'delete_design']);
    });

    Route::group(['prefix' => "/videos"], function () {
        Route::get('/', [AdminMotionController::class, 'get_videos']);
        Route::post('/create', [AdminMotionController::class, 'add_video']);
        Route::get('/delete/{id}', [AdminMotionController::class, 'delete_video']);
    });

    Route::group(['prefix' => "/apps"], function () {
        Route::get('/', [AdminAppController::class, 'get_apps']);
        Route::post('/create', [AdminAppController::class, 'add_app']);
        Route::post('/update', [AdminAppController::class, 'update_app']);
        Route::get('/delete/{id}', [AdminAppController::class, 'delete_app']);
    });
});



Route::get('/unAuthorized', function () {
    return response()->json([
        'error' => "Anauthorized operation",
    ],401);
})->name('unAuthorized');
