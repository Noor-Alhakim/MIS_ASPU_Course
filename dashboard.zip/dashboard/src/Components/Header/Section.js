import React from "react";

export default function Section({ value }) {
  return <span className="section  mx-md-2 d-md-inline d-none">{value}</span>;
}
